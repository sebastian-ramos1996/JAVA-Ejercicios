package org.example.ejercicio1;

public interface Pagable   {

    double calcularPago();
    double aplciarDescuento(double porcentaje);

    String descripcion();
}
