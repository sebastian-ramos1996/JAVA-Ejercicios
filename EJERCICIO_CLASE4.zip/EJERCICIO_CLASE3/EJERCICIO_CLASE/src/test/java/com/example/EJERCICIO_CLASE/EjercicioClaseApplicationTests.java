package com.example.EJERCICIO_CLASE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
