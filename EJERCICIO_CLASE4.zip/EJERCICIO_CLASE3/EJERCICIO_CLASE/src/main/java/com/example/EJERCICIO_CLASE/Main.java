package com.example.EJERCICIO_CLASE;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<RecursoDigital> lista = new ArrayList<>();

        lista.add(new LibroElectronico("Libro A", "Autor 1", 2010, "PDF", 2.5, 200, true));
        lista.add(new LibroElectronico("Libro B", "Autor 2", 2005, "EPUB", 1.8, 150, false));
        lista.add(new LibroElectronico("Libro C", "Autor 3", 2018, "PDF", 3.0, 300, true));


        for (RecursoDigital r : lista) {
            System.out.println(r.obtenerResumen());
        }


        LibroElectronico masAntiguo = null;

        for (RecursoDigital r : lista) {
            if (r instanceof LibroElectronico) {
                LibroElectronico libro = (LibroElectronico) r;

                if (masAntiguo == null ||
                        libro.getAnioPublicacion() < masAntiguo.getAnioPublicacion()) {
                    masAntiguo = libro;
                }
            }
        }

        System.out.println("\nLibro electrónico más antiguo:");
        System.out.println(masAntiguo.obtenerResumen());
    }
}