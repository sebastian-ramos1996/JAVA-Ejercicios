package com.example.EJERCICIO_CLASE;

class LibroElectronico extends RecursoDigital {
    private int numeroPaginas;
    private boolean tieneDRM;

    public LibroElectronico(String titulo, String autor, int anioPublicacion,
                            String formato, double tamanioMB,
                            int numeroPaginas, boolean tieneDRM) {
        super(titulo, autor, anioPublicacion, formato, tamanioMB);
        this.numeroPaginas = numeroPaginas;
        this.tieneDRM = tieneDRM;
    }

    @Override
    public String obtenerResumen() {
        return "Libro: " + titulo +
                ", Autor: " + autor +
                ", Año: " + anioPublicacion +
                ", Formato: " + formato +
                ", Páginas: " + numeroPaginas +
                ", DRM: " + (tieneDRM ? "Sí" : "No");
    }
}
