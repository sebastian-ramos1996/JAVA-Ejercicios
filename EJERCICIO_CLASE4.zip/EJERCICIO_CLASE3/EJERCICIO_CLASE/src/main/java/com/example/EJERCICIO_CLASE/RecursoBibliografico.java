package com.example.EJERCICIO_CLASE;

public class RecursoBibliografico {
    private String titulo;
    private String autor;
    private int anioPublicacion;

    public RecursoBibliografico(String titulo, String autor, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
    }

    public abstract String obtenerResumen();

    public int getAnioPublicacion() {
        return anioPublicacion;
    }
}