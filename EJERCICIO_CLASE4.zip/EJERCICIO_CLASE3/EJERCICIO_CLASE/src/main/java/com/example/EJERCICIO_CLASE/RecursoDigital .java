package com.example.EJERCICIO_CLASE;

class RecursoDigital extends RecursoBibliografico {
    private String formato;
    private double tamanioMB;

    public RecursoDigital(String titulo, String autor, int anioPublicacion,
                          String formato, double tamanioMB) {
        super(titulo, autor, anioPublicacion);
        this.formato = formato;
        this.tamanioMB = tamanioMB;
    }

    @Override
    public String obtenerResumen() {
        return "Recurso digital: " + titulo + " (" + formato + ")";
    }
}