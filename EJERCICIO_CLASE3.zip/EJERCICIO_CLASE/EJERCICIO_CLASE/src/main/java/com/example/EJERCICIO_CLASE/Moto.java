package com.example.EJERCICIO_CLASE;

public class Moto extends VehiculoElectrico {
    private String marca;
    private double distanciaRecor;
    private String color;

    public Moto(String marca, double distanciaRecor, String color) {
        this.marca = marca;
        this.distanciaRecor = distanciaRecor;
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public double getDistanciaRecor() {
        return distanciaRecor;
    }

    public String getColor() {
        return color;
    }
}