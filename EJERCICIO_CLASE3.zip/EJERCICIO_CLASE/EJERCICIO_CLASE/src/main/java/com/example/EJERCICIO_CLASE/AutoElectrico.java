package com.example.EJERCICIO_CLASE;

public class AutoElectrico implements Auto {
    private String color;
    private double precioAuto;
    private double gastoEnergia;

    public AutoElectrico(String color, double precioAuto,double gastoEnergia) {
        this.color = color;
        this.precioAuto = precioAuto;
        this.gastoEnergia= gastoEnergia;
    }


    @Override
    public double calcularCostoViaje(){

        return (gastoEnergia * 165)/100;
    }

    public String getColor() {
        return color;
    }

    public double getPrecioAuto() {
        return precioAuto;
    }
}