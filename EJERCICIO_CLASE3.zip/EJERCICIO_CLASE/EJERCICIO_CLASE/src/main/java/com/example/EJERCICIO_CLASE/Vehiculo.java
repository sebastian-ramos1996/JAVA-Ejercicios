package com.example.EJERCICIO_CLASE;

public interface Vehiculo {
    double calcularCostoViaje();

}
