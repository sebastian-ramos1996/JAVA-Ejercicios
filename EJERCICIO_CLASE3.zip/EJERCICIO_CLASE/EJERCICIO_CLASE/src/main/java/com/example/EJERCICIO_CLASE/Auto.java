package com.example.EJERCICIO_CLASE;

public class Auto extends VehiculoElectrico {
    private String marca;
    private double distanciaRecor;

    public Auto(String marca, double distanciaRecor) {
        this.marca = marca;
        this.distanciaRecor = distanciaRecor;
    }

    public double getDistanciaRecor() {
        return distanciaRecor;
    }

    public String getMarca() {
        return marca;
    }
}