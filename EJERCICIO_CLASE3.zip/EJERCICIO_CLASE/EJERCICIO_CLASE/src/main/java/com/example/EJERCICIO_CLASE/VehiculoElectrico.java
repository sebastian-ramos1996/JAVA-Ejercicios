package com.example.EJERCICIO_CLASE;

public class VehiculoElectrico extends Vehiculo {
    private String marca;
    private int numLlantas;
    private double distanciaRecor;

    public Vehiculo(String marca, int numLlantas, double distanciaRecor) {
        this.marca = marca;
        this.numLlantas = numLlantas;
        this.distanciaRecor= distanciaRecor;
    }

    @Override
    public double calcularCostoViaje(double distanciaRecor){
        return distanciaRecor*1500
    }

    public String getMarca() {
        return marca;
    }

    public int getNumLlantas() {
        return numLlantas;
    }

    @java.lang.Override
    public java.lang.String toString() {
        double costo;
        return "VehiculoElectrico{" +
                "distanciaRecor= " + distanciaRecor +
                '}' + "Costo de viaje= " + costo.calcularCostoViaje();
    }
}