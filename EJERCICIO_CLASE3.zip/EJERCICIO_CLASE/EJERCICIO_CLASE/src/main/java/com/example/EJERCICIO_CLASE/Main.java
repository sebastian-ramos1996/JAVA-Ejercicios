package com.example.EJERCICIO_CLASE;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {

        // Main.java

        VehiculoElectrico vehiculoE1 = new VehiculoElectrico("Moto1",2,100);
        AutoElectrico AutoEl1 = new AutoElectrico("verde",350,5500);

        vehiculoE1.calcularCostoViaje(100);

        AutoElectrico.calcularCostoViaje();


        List<Vehiculo> flota = new ArrayList<>();

        flota.add(new AutoElectrico("Azul", 100, 4000));
        flota.add(new VehiculoElectrico("MotoElectrica", 2, 350));
        flota.add(new Moto("Suzuki", 6400, "roja"));





    }
}